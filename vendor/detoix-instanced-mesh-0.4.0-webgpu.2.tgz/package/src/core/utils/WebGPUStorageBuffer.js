import { IndirectStorageBufferAttribute, StorageBufferAttribute } from 'three/webgpu';
/**
 * CPU-backed storage buffer with one contiguous dirty range.
 *
 * Calls to `enqueueUpdate()` only widen the pending range; they never create
 * one update range per instance.
 */
class WebGPUStorageBuffer {
    constructor(itemSize, capacity, name) {
        /** Increments whenever `attribute` is replaced. */
        this.revision = 0;
        /**
         * Installed by the owning mesh so every attribute this buffer drops — on
         * dispose and on each reallocation — also releases its GPU buffer.
         */
        this.onReleaseAttribute = null;
        this._dirtyStart = Infinity;
        this._dirtyEnd = 0;
        assertPositiveInteger(itemSize, 'itemSize');
        assertNonNegativeInteger(capacity, 'capacity');
        this.itemSize = itemSize;
        this._data = this.allocate(capacity * itemSize);
        this.attribute = createStorageAttribute(this._data, itemSize, name);
    }
    /** Number of logical items currently allocated. */
    get capacity() {
        return this._data.length / this.itemSize;
    }
    /**
     * Marks a logical item as changed. Multiple calls are coalesced into one
     * component range by `flush()`.
     */
    enqueueUpdate(index) {
        assertIndex(index, this.capacity);
        const start = index * this.itemSize;
        this._dirtyStart = Math.min(this._dirtyStart, start);
        this._dirtyEnd = Math.max(this._dirtyEnd, start + this.itemSize);
    }
    /** Marks every allocated item as changed. */
    enqueueFullUpdate() {
        if (this._data.length === 0)
            return;
        this._dirtyStart = 0;
        this._dirtyEnd = this._data.length;
    }
    /**
     * Publishes the pending CPU changes to Three.js.
     *
     * `count` optionally limits the upload to the first N logical items. Any
     * pending tail remains queued for a later flush. Existing, not-yet-consumed
     * Three.js update ranges are merged so there is always at most one range.
     *
     * @returns `true` when an upload was scheduled.
     */
    flush(count = this.capacity) {
        assertCount(count, this.capacity);
        if (this._dirtyStart === Infinity)
            return false;
        const componentLimit = count * this.itemSize;
        const uploadEnd = Math.min(this._dirtyEnd, componentLimit);
        if (this._dirtyStart >= uploadEnd)
            return false;
        let uploadStart = this._dirtyStart;
        let mergedEnd = uploadEnd;
        for (const range of this.attribute.updateRanges) {
            uploadStart = Math.min(uploadStart, range.start);
            mergedEnd = Math.max(mergedEnd, range.start + range.count);
        }
        this.attribute.clearUpdateRanges();
        this.attribute.addUpdateRange(uploadStart, mergedEnd - uploadStart);
        this.attribute.needsUpdate = true;
        if (uploadEnd < this._dirtyEnd) {
            this._dirtyStart = uploadEnd;
        }
        else {
            this.clearPendingRange();
        }
        return true;
    }
    /**
     * Reallocates the storage attribute while preserving the overlapping data.
     * Consumers holding a TSL storage node must rebuild it when `revision`
     * changes because the `attribute` identity changes.
     */
    resize(capacity) {
        assertNonNegativeInteger(capacity, 'capacity');
        if (capacity === this.capacity)
            return;
        const data = this.allocate(capacity * this.itemSize);
        data.set(this._data.subarray(0, Math.min(this._data.length, data.length)));
        this.replaceData(data);
    }
    dispose() {
        releaseAttribute(this.attribute, this.onReleaseAttribute);
        this.clearPendingRange();
    }
    replaceData(data) {
        if (data.length % this.itemSize !== 0) {
            throw new RangeError(`Storage data length must be divisible by itemSize (${this.itemSize}).`);
        }
        if (data === this._data)
            return;
        const previousAttribute = this.attribute;
        this._data = data;
        this.attribute = createStorageAttribute(data, this.itemSize, previousAttribute.name);
        this.revision++;
        this.clearPendingRange();
        releaseAttribute(previousAttribute, this.onReleaseAttribute);
    }
    clearPendingRange() {
        this._dirtyStart = Infinity;
        this._dirtyEnd = 0;
    }
}
/**
 * Float storage buffer, suitable for matrices (`itemSize = 16`) and colors
 * (`itemSize = 4`).
 */
export class WebGPUFloatStorageBuffer extends WebGPUStorageBuffer {
    constructor(itemSize, capacity, name = '') {
        super(itemSize, capacity, name);
        this.image = this.createImageView();
    }
    clone() {
        const clone = new WebGPUFloatStorageBuffer(this.itemSize, this.capacity, this.attribute.name);
        clone._data.set(this._data);
        return clone;
    }
    allocate(length) {
        return new Float32Array(length);
    }
    replaceData(data) {
        if (!(data instanceof Float32Array)) {
            throw new TypeError('WebGPUFloatStorageBuffer data must be a Float32Array.');
        }
        super.replaceData(data);
    }
    createImageView() {
        const owner = this;
        const image = {};
        Object.defineProperties(image, {
            data: {
                enumerable: true,
                get() {
                    return owner._data;
                },
                set(value) {
                    owner.replaceData(value);
                }
            },
            width: {
                enumerable: true,
                get() {
                    return owner.capacity;
                }
            },
            height: {
                enumerable: true,
                get() {
                    return 1;
                }
            }
        });
        return image;
    }
}
/** Bit 0 of an instance state word: the instance is visible. */
export const INSTANCE_STATE_VISIBLE = 1;
/** Bit 1 of an instance state word: the instance is active (not deleted). */
export const INSTANCE_STATE_ACTIVE = 2;
/** Bit offset of the render-pass LOD override field (0 means "no override"). */
export const INSTANCE_STATE_RENDER_LOD_SHIFT = 8;
/** Bit offset of the shadow-pass LOD override field (0 means "no override"). */
export const INSTANCE_STATE_SHADOW_LOD_SHIFT = 16;
/** Mask of one LOD override field. */
export const INSTANCE_STATE_LOD_MASK = 0xff;
/**
 * One `u32` of GPU-readable per-instance state: the active and visible flags
 * the CPU already tracks in `availabilityArray`, plus optional per-pass LOD
 * overrides. See `docs/webgpu-architecture.md`.
 */
export class WebGPUInstanceStateBuffer extends WebGPUStorageBuffer {
    constructor(capacity, name = 'ezInstanceState') {
        super(1, capacity, name);
    }
    setFlag(index, flag, value) {
        const previous = this._data[index];
        const next = value ? previous | flag : previous & ~flag;
        if (next === previous)
            return;
        this._data[index] = next;
        this.enqueueUpdate(index);
    }
    setFlags(index, mask, value) {
        const previous = this._data[index];
        const next = value ? previous | mask : previous & ~mask;
        if (next === previous)
            return;
        this._data[index] = next;
        this.enqueueUpdate(index);
    }
    /** `level < 0` clears the override and restores distance-based selection. */
    setLODOverride(index, level, shift) {
        const stored = level < 0 ? 0 : Math.min(level + 1, INSTANCE_STATE_LOD_MASK);
        const previous = this._data[index];
        const next = (previous & ~(INSTANCE_STATE_LOD_MASK << shift)) | (stored << shift);
        if (next === previous)
            return;
        this._data[index] = next;
        this.enqueueUpdate(index);
    }
    getLODOverride(index, shift) {
        return ((this._data[index] >>> shift) & INSTANCE_STATE_LOD_MASK) - 1;
    }
    allocate(length) {
        return new Uint32Array(length);
    }
}
/** `u32` words in one indexed indirect draw command. */
export const DRAW_COMMAND_WORDS = 5;
/** Bytes in one indirect draw command slot. */
export const DRAW_COMMAND_BYTES = DRAW_COMMAND_WORDS * Uint32Array.BYTES_PER_ELEMENT;
/**
 * Indirect draw commands whose `instanceCount` word is written by the culling
 * compute pass rather than by the CPU.
 *
 * A single 5-word stride serves both layouts. WebGPU reads
 * `(indexCount, instanceCount, firstIndex, baseVertex, firstInstance)` for an
 * indexed draw and `(vertexCount, instanceCount, firstVertex, firstInstance)`
 * for a non-indexed one, so word 1 is `instanceCount` either way and the
 * shader never needs to know which geometry it is looking at.
 */
export class WebGPUIndirectDrawBuffer {
    constructor(commandCount, name = 'ezIndirectDraws') {
        /** Increments whenever `attribute` is replaced. */
        this.revision = 0;
        /**
         * Installed by the owning culling pass so every attribute this buffer drops —
         * on dispose and on each reallocation — also releases its GPU buffer. Indirect
         * attributes are counted separately by three, under
         * `info.memory.indirectStorageAttributes`.
         */
        this.onReleaseAttribute = null;
        assertPositiveInteger(commandCount, 'commandCount');
        this._data = new Uint32Array(commandCount * DRAW_COMMAND_WORDS);
        this.attribute = createIndirectAttribute(this._data, name);
    }
    get commandCount() {
        return this._data.length / DRAW_COMMAND_WORDS;
    }
    byteOffset(command) {
        return command * DRAW_COMMAND_BYTES;
    }
    setCommandCount(commandCount) {
        assertPositiveInteger(commandCount, 'commandCount');
        if (commandCount === this.commandCount)
            return;
        const previousAttribute = this.attribute;
        this._data = new Uint32Array(commandCount * DRAW_COMMAND_WORDS);
        this.attribute = createIndirectAttribute(this._data, previousAttribute.name);
        this.revision++;
        releaseAttribute(previousAttribute, this.onReleaseAttribute);
    }
    /**
     * Writes the geometry-dependent words of one command. `instanceCount` is
     * deliberately left at zero: the compute pass owns it, and re-uploading it
     * would race with the counts already on the GPU.
     *
     * @returns `true` when the command actually changed.
     */
    writeCommand(command, elementCount, firstElement, _indexed) {
        // The remaining words -- baseVertex and firstInstance when indexed,
        // firstInstance when not -- are zero in both layouts.
        const base = command * DRAW_COMMAND_WORDS;
        const data = this._data;
        if (data[base] === elementCount && data[base + 2] === firstElement)
            return false;
        data[base] = elementCount;
        data[base + 2] = firstElement;
        return true;
    }
    upload() {
        this.attribute.needsUpdate = true;
    }
    dispose() {
        releaseAttribute(this.attribute, this.onReleaseAttribute);
    }
}
/**
 * CPU-written visible-instance indirection buffer for WebGPU.
 *
 * Its `array`, `_needsUpdate`, and `update(renderer, count)` surface mirrors
 * the existing WebGL index attribute closely enough for the shared culling
 * and LOD code. Each update uploads one `[0, count)` range. On the GPU-driven
 * path the same attribute is written by a compute shader instead and no CPU
 * upload happens at all.
 */
export class WebGPUVisibleIndexBuffer {
    constructor(capacity, name = 'ezInstanceIndex') {
        this._needsUpdate = true;
        /** Increments whenever `attribute` is replaced. */
        this.revision = 0;
        /**
         * Installed by the owning mesh so every attribute this buffer drops — on
         * dispose and on each reallocation — also releases its GPU buffer.
         */
        this.onReleaseAttribute = null;
        assertNonNegativeInteger(capacity, 'capacity');
        this._array = new Uint32Array(capacity);
        fillIdentity(this._array);
        this.attribute = createStorageAttribute(this._array, 1, name);
    }
    get array() {
        return this._array;
    }
    set array(value) {
        this.replaceArray(value);
    }
    get capacity() {
        return this._array.length;
    }
    /**
     * Reallocates the storage attribute, preserves existing indices, and fills
     * newly allocated entries with their identity index.
     */
    resize(capacity) {
        assertNonNegativeInteger(capacity, 'capacity');
        if (capacity === this.capacity)
            return;
        const previousCapacity = this.capacity;
        const array = new Uint32Array(capacity);
        array.set(this._array.subarray(0, Math.min(previousCapacity, capacity)));
        for (let i = previousCapacity; i < capacity; i++) {
            array[i] = i;
        }
        this.replaceArray(array);
    }
    /**
     * Schedules one contiguous upload for the visible prefix. The renderer
     * parameter is intentionally unused; it is retained for WebGL API parity.
     */
    update(_renderer, count) {
        if (!this._needsUpdate || count === 0)
            return false;
        assertCount(count, this.capacity);
        this.attribute.clearUpdateRanges();
        this.attribute.addUpdateRange(0, count);
        this.attribute.needsUpdate = true;
        this._needsUpdate = false;
        return true;
    }
    /** Renderer-independent alias for `update()`. */
    flush(count) {
        return this.update(undefined, count);
    }
    clone() {
        const clone = new WebGPUVisibleIndexBuffer(this.capacity, this.attribute.name);
        clone._array.set(this._array);
        clone._needsUpdate = this._needsUpdate;
        return clone;
    }
    dispose() {
        releaseAttribute(this.attribute, this.onReleaseAttribute);
        this._needsUpdate = false;
    }
    replaceArray(array) {
        if (!(array instanceof Uint32Array)) {
            throw new TypeError('WebGPUVisibleIndexBuffer array must be a Uint32Array.');
        }
        if (array === this._array)
            return;
        const previousAttribute = this.attribute;
        const previousCapacity = this.capacity;
        for (let i = previousCapacity; i < array.length; i++) {
            array[i] = i;
        }
        this._array = array;
        this.attribute = createStorageAttribute(array, 1, previousAttribute.name);
        this._needsUpdate = true;
        this.revision++;
        releaseAttribute(previousAttribute, this.onReleaseAttribute);
    }
}
/**
 * Retires an attribute that is no longer in use.
 *
 * `dispose()` is kept for consumers listening for the event, but it frees
 * nothing by itself; `onRelease` is what actually returns the GPU buffer.
 */
function releaseAttribute(attribute, onRelease) {
    attribute.dispose();
    attribute.clearUpdateRanges();
    onRelease?.(attribute);
}
function createStorageAttribute(array, itemSize, name) {
    const attribute = new StorageBufferAttribute(array, itemSize);
    attribute.name = name;
    return attribute;
}
/**
 * The attribute is declared one `u32` per item on purpose. A struct-typed
 * storage binding whose array holds exactly one element is emitted by Three as
 * a bare struct rather than a runtime-sized array, which the compute kernel
 * then cannot index. Words are addressed explicitly instead.
 */
function createIndirectAttribute(array, name) {
    const attribute = new IndirectStorageBufferAttribute(array, 1);
    attribute.name = name;
    return attribute;
}
function fillIdentity(array) {
    for (let i = 0; i < array.length; i++) {
        array[i] = i;
    }
}
function assertPositiveInteger(value, name) {
    if (!Number.isInteger(value) || value <= 0) {
        throw new RangeError(`${name} must be a positive integer.`);
    }
}
function assertNonNegativeInteger(value, name) {
    if (!Number.isInteger(value) || value < 0) {
        throw new RangeError(`${name} must be a non-negative integer.`);
    }
}
function assertIndex(index, capacity) {
    if (!Number.isInteger(index) || index < 0 || index >= capacity) {
        throw new RangeError(`index must be an integer in [0, ${capacity}).`);
    }
}
function assertCount(count, capacity) {
    if (!Number.isInteger(count) || count < 0 || count > capacity) {
        throw new RangeError(`count must be an integer in [0, ${capacity}].`);
    }
}
//# sourceMappingURL=WebGPUStorageBuffer.js.map