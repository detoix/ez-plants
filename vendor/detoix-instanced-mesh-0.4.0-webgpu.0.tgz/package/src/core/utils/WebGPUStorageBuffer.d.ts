import { IndirectStorageBufferAttribute, StorageBufferAttribute, type WebGPURenderer } from 'three/webgpu';
/**
 * Minimal image-shaped view used by {@link WebGPUFloatStorageBuffer}.
 *
 * `InstancedMesh2` historically stores instance data in a `DataTexture`, so
 * some of its common code accesses `image.data`. The accessor below keeps
 * that API without allocating a texture or duplicating the backing array.
 */
export interface WebGPUStorageBufferImage {
    data: Float32Array;
    readonly width: number;
    readonly height: number;
}
type StorageArray = Float32Array | Uint32Array;
/**
 * CPU-backed storage buffer with one contiguous dirty range.
 *
 * Calls to `enqueueUpdate()` only widen the pending range; they never create
 * one update range per instance.
 */
declare abstract class WebGPUStorageBuffer<TArray extends StorageArray> {
    _data: TArray;
    attribute: StorageBufferAttribute;
    readonly itemSize: number;
    /** Increments whenever `attribute` is replaced. */
    revision: number;
    private _dirtyStart;
    private _dirtyEnd;
    constructor(itemSize: number, capacity: number, name: string);
    /** Number of logical items currently allocated. */
    get capacity(): number;
    /**
     * Marks a logical item as changed. Multiple calls are coalesced into one
     * component range by `flush()`.
     */
    enqueueUpdate(index: number): void;
    /** Marks every allocated item as changed. */
    enqueueFullUpdate(): void;
    /**
     * Publishes the pending CPU changes to Three.js.
     *
     * `count` optionally limits the upload to the first N logical items. Any
     * pending tail remains queued for a later flush. Existing, not-yet-consumed
     * Three.js update ranges are merged so there is always at most one range.
     *
     * @returns `true` when an upload was scheduled.
     */
    flush(count?: number): boolean;
    /**
     * Reallocates the storage attribute while preserving the overlapping data.
     * Consumers holding a TSL storage node must rebuild it when `revision`
     * changes because the `attribute` identity changes.
     */
    resize(capacity: number): void;
    dispose(): void;
    protected abstract allocate(length: number): TArray;
    protected replaceData(data: TArray): void;
    private clearPendingRange;
}
/**
 * Float storage buffer, suitable for matrices (`itemSize = 16`) and colors
 * (`itemSize = 4`).
 */
export declare class WebGPUFloatStorageBuffer extends WebGPUStorageBuffer<Float32Array> {
    readonly image: WebGPUStorageBufferImage;
    constructor(itemSize: number, capacity: number, name?: string);
    clone(): WebGPUFloatStorageBuffer;
    protected allocate(length: number): Float32Array;
    protected replaceData(data: Float32Array): void;
    private createImageView;
}
/** Bit 0 of an instance state word: the instance is visible. */
export declare const INSTANCE_STATE_VISIBLE = 1;
/** Bit 1 of an instance state word: the instance is active (not deleted). */
export declare const INSTANCE_STATE_ACTIVE = 2;
/** Bit offset of the render-pass LOD override field (0 means "no override"). */
export declare const INSTANCE_STATE_RENDER_LOD_SHIFT = 8;
/** Bit offset of the shadow-pass LOD override field (0 means "no override"). */
export declare const INSTANCE_STATE_SHADOW_LOD_SHIFT = 16;
/** Mask of one LOD override field. */
export declare const INSTANCE_STATE_LOD_MASK = 255;
/**
 * One `u32` of GPU-readable per-instance state: the active and visible flags
 * the CPU already tracks in `availabilityArray`, plus optional per-pass LOD
 * overrides. See `docs/webgpu-architecture.md`.
 */
export declare class WebGPUInstanceStateBuffer extends WebGPUStorageBuffer<Uint32Array> {
    constructor(capacity: number, name?: string);
    setFlag(index: number, flag: number, value: boolean): void;
    setFlags(index: number, mask: number, value: boolean): void;
    /** `level < 0` clears the override and restores distance-based selection. */
    setLODOverride(index: number, level: number, shift: number): void;
    getLODOverride(index: number, shift: number): number;
    protected allocate(length: number): Uint32Array;
}
/** `u32` words in one indexed indirect draw command. */
export declare const DRAW_COMMAND_WORDS = 5;
/** Bytes in one indirect draw command slot. */
export declare const DRAW_COMMAND_BYTES: number;
/**
 * Indirect draw commands whose `instanceCount` word is written by the culling
 * compute pass rather than by the CPU.
 *
 * A single 5-word stride serves both layouts. WebGPU reads
 * `(indexCount, instanceCount, firstIndex, baseVertex, firstInstance)` for an
 * indexed draw and `(vertexCount, instanceCount, firstVertex, firstInstance)`
 * for a non-indexed one, so word 1 is `instanceCount` either way and the
 * shader never needs to know which geometry it is looking at.
 */
export declare class WebGPUIndirectDrawBuffer {
    attribute: IndirectStorageBufferAttribute;
    /** Increments whenever `attribute` is replaced. */
    revision: number;
    private _data;
    constructor(commandCount: number, name?: string);
    get commandCount(): number;
    byteOffset(command: number): number;
    setCommandCount(commandCount: number): void;
    /**
     * Writes the geometry-dependent words of one command. `instanceCount` is
     * deliberately left at zero: the compute pass owns it, and re-uploading it
     * would race with the counts already on the GPU.
     *
     * @returns `true` when the command actually changed.
     */
    writeCommand(command: number, elementCount: number, firstElement: number, _indexed: boolean): boolean;
    upload(): void;
    dispose(): void;
}
/**
 * CPU-written visible-instance indirection buffer for WebGPU.
 *
 * Its `array`, `_needsUpdate`, and `update(renderer, count)` surface mirrors
 * the existing WebGL index attribute closely enough for the shared culling
 * and LOD code. Each update uploads one `[0, count)` range. On the GPU-driven
 * path the same attribute is written by a compute shader instead and no CPU
 * upload happens at all.
 */
export declare class WebGPUVisibleIndexBuffer {
    attribute: StorageBufferAttribute;
    _needsUpdate: boolean;
    /** Increments whenever `attribute` is replaced. */
    revision: number;
    private _array;
    constructor(capacity: number, name?: string);
    get array(): Uint32Array;
    set array(value: Uint32Array);
    get capacity(): number;
    /**
     * Reallocates the storage attribute, preserves existing indices, and fills
     * newly allocated entries with their identity index.
     */
    resize(capacity: number): void;
    /**
     * Schedules one contiguous upload for the visible prefix. The renderer
     * parameter is intentionally unused; it is retained for WebGL API parity.
     */
    update(_renderer: WebGPURenderer | null | undefined, count: number): boolean;
    /** Renderer-independent alias for `update()`. */
    flush(count: number): boolean;
    clone(): WebGPUVisibleIndexBuffer;
    dispose(): void;
    private replaceArray;
}
export {};
//# sourceMappingURL=WebGPUStorageBuffer.d.ts.map