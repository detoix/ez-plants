import { Camera, Matrix4, Sphere } from 'three';
import type { StorageBufferAttribute } from 'three/webgpu';
import { WebGPUIndirectDrawBuffer } from './WebGPUStorageBuffer.js';
/** One geometry sub-range drawn with its own material. */
export interface CullingDrawRange {
    elementCount: number;
    firstElement: number;
}
/** One LOD level, or the single level of a mesh without LODs. */
export interface CullingLevelDescriptor {
    visibleAttribute: StorageBufferAttribute;
    /** Squared distance threshold, before hysteresis. Ignored for level 0. */
    distanceSquared: number;
    hysteresis: number;
    indexed: boolean;
    ranges: CullingDrawRange[];
}
export interface CullingPassDescriptor {
    matrixAttribute: StorageBufferAttribute;
    stateAttribute: StorageBufferAttribute;
    capacity: number;
    /** Bit offset of the LOD override field this pass reads. */
    lodOverrideShift: number;
    levels: CullingLevelDescriptor[];
}
/**
 * True when a descriptor's level count fits inside the device's per-stage
 * storage-buffer limit. Callers fall back to CPU culling when it does not.
 */
export declare function fitsStorageBindings(levelCount: number, maxStorageBuffersPerShaderStage: number): boolean;
/**
 * One GPU culling + LOD-classification dispatch for a single render pass.
 *
 * The compute kernel reads the persistent instance matrices and per-instance
 * state, tests an object-space bounding sphere against the six object-space
 * frustum planes, classifies the survivor into a LOD level, and appends its
 * id to that level's visible list through an atomic increment of the level's
 * indirect `instanceCount`. See `docs/webgpu-architecture.md`.
 */
export declare class WebGPUCullingPass {
    readonly indirect: WebGPUIndirectDrawBuffer;
    /** Increments whenever the compute graph is rebuilt. */
    revision: number;
    private readonly _name;
    private readonly _planeUniforms;
    private _levelCount;
    private _rangeCounts;
    private _commandBase;
    private _cameraPosUniform;
    private _sphereCenterUniform;
    private _sphereRadiusUniform;
    private _cullEnabledUniform;
    private _thresholdUniforms;
    private _resetNode;
    private _cullNode;
    private _publishNode;
    private _computeNodes;
    private _disposed;
    constructor(name: string);
    /** Byte offset of the indirect command for one level and draw range. */
    commandByteOffset(level: number, range: number): number;
    /**
     * (Re)builds the compute graph. Cheap to call when nothing structural
     * changed: it returns early unless a rebuild is actually required.
     */
    build(descriptor: CullingPassDescriptor): void;
    /**
     * Rewrites the geometry-dependent command words without a graph rebuild, and
     * uploads only when one actually changed. An upload also resets the counts
     * the previous frame's kernel wrote, so it must not happen every frame.
     */
    writeCommands(descriptor: CullingPassDescriptor): void;
    /**
     * Uploads the frustum planes and LOD camera position for this dispatch,
     * both expressed in the mesh's object space so the kernel can use the
     * instance matrices directly.
     */
    setCamera(camera: Camera, cameraLOD: Camera, matrixWorld: Matrix4, perObjectFrustumCulled: boolean, sphere: Sphere): void;
    /** Refreshes the LOD thresholds without rebuilding the compute graph. */
    setLevelDistances(levels: CullingLevelDescriptor[]): void;
    /**
     * Sizes the cull dispatch and returns the kernels to submit, or `null` when
     * there is nothing to cull. Submitting is the caller's job so that every
     * mesh in a pass can share one command buffer.
     */
    prepare(instanceCount: number): any[] | null;
    get levelCount(): number;
    get rangeCounts(): number[];
    dispose(): void;
    private disposeKernels;
}
//# sourceMappingURL=WebGPUCullingPipeline.d.ts.map