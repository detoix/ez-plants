import { type BufferGeometry, type Camera, Material, type Mesh, type Object3DEventMap, type Scene, type Skeleton, type WebGPURenderer } from 'three/webgpu';
import { InstancedMesh2, type InstancedMesh2Params } from './InstancedMesh2.js';
/**
 * Selects where per-instance frustum culling and LOD selection run.
 *
 * `'auto'` takes the GPU path whenever the mesh's configuration allows it and
 * keeps the shared CPU path otherwise. `'gpu'` additionally warns when a
 * configuration forces the fallback. See `docs/webgpu-architecture.md`.
 */
export type WebGPUCullingMode = 'auto' | 'gpu' | 'cpu';
export interface InstancedMesh2WebGPUParams extends Omit<InstancedMesh2Params, 'renderer'> {
    /**
     * Accepted for constructor parity. WebGPU buffers do not need a renderer in
     * order to be allocated, so initialization remains eager without it.
     */
    renderer?: WebGPURenderer;
    /**
     * Where per-instance frustum culling and LOD selection run.
     * @default 'auto'
     */
    culling?: WebGPUCullingMode;
}
/**
 * WebGPU renderer backend for InstancedMesh2.
 *
 * Instance allocation, stable ids, BVH and raycasting remain inherited from
 * the shared core, and so does the CPU culling path used as a fallback. On
 * top of the WebGL texture/attribute replacement this class adds a GPU-driven
 * render path: persistent storage buffers, a TSL compute pass that culls and
 * classifies every instance, and indirect draws whose instance counts are
 * produced on the GPU. See `docs/webgpu-architecture.md`.
 */
export declare class InstancedMesh2WebGPU<TData = {}, TGeometry extends BufferGeometry = BufferGeometry, TMaterial extends Material | Material[] = Material | Material[], TEventMap extends Object3DEventMap = Object3DEventMap> extends InstancedMesh2<TData, TGeometry, TMaterial, TEventMap> {
    private _ownedWebGPUMaterials;
    private _shadowInstanceIndex;
    private _shadowPassDepth;
    private _webgpuBindingRevision;
    private _webgpuDisposed;
    private _instanceState;
    private _cullingMode;
    private _cullPasses;
    private _cullDescriptors;
    private _pendingCull;
    private _cullNeedsRebuild;
    private _cullFallbackWarned;
    private _webgpuRenderer;
    private _gpuCullingCached;
    private _gpuCullingRenderCall;
    private _singleLevel;
    private _lastRenderCamera;
    get material(): TMaterial;
    set material(value: TMaterial);
    constructor(geometry: TGeometry, material: TMaterial, params?: InstancedMesh2WebGPUParams, LOD?: InstancedMesh2WebGPU);
    constructor(geometry: TGeometry, material: TMaterial, params?: InstancedMesh2WebGPUParams);
    /**
     * Where per-instance frustum culling and LOD selection run. Setting this on
     * a LOD child forwards to its owner.
     */
    get culling(): WebGPUCullingMode;
    set culling(value: WebGPUCullingMode);
    /**
     * Whether the GPU-driven path is currently in use. `false` means the shared
     * CPU culling path runs instead, which is always a correct fallback.
     */
    get gpuCullingActive(): boolean;
    /**
     * Forces one instance onto a specific LOD level, replacing the distance
     * test for that instance. This is the GPU-readable equivalent of the CPU
     * `resolveLODIndex` callback, which cannot run inside a compute shader.
     *
     * @param id The instance id.
     * @param level The level index, or `-1` to restore distance selection.
     * @param isShadowPass Target the shadow LOD list instead of the render one.
     */
    setLODOverrideAt(id: number, level: number, isShadowPass?: boolean): void;
    /**
     * The LOD level forced on one instance, or `-1` when the distance test
     * decides.
     */
    getLODOverrideAt(id: number, isShadowPass?: boolean): number;
    /**
     * Reads back the instance count each LOD level actually drew.
     *
     * On the GPU path `count` is only an upper bound, because the real number
     * is produced by the compute pass. This is the exact figure, one or more
     * frames late, and it costs a GPU readback: call it for statistics, never
     * per frame in a render loop.
     *
     * @returns One count per level of the requested pass, or `null` when the
     * GPU path is not active.
     */
    getVisibleCountsAsync(isShadowPass?: boolean): Promise<number[] | null>;
    protected initIndexAttribute(): void;
    protected initMatricesTexture(): void;
    protected initColorsTexture(): void;
    /** WebGPU does not add a synthetic vertex attribute to user geometry. */
    protected patchGeometry(_geometry: TGeometry): void;
    protected materialsNeedsUpdate(): void;
    setVisibilityAt(id: number, visible: boolean): void;
    setActiveAt(id: number, active: boolean): void;
    setActiveAndVisibilityAt(id: number, value: boolean): void;
    onBeforeShadow(renderer: any, _scene: Scene, _camera: Camera, shadowCamera: Camera, _geometry: BufferGeometry, _depthMaterial: Material, group: any): void;
    onBeforeRender(renderer: any, _scene: Scene, camera: Camera, _geometry: BufferGeometry, _material: Material, group: any): void;
    onAfterShadow(_renderer: any, _scene: Scene, _camera: Camera, _shadowCamera: Camera, _geometry: BufferGeometry, _depthMaterial: Material, _group: any): void;
    onAfterRender(_renderer: any, _scene: Scene, _camera: Camera, _geometry: BufferGeometry, _material: Material, _group: any): void;
    /**
     * On the GPU path this records the request and the dispatch happens at draw
     * time, when a renderer is available. The CPU path runs immediately, as
     * before.
     */
    performFrustumCulling(camera: Camera, cameraLOD?: Camera, isShadowPass?: boolean): void;
    resizeBuffers(capacity: number): this;
    initUniformsPerInstance(_schema: unknown): void;
    initSkeleton(_skeleton: Skeleton, _disableMatrixAutoUpdate?: boolean): void;
    setMorphAt(_id: number, _object: Mesh): void;
    clone(_recursive?: boolean): this;
    copy(_source: InstancedMesh2, _recursive?: boolean): this;
    dispose(): void;
    /** The path decision for one pass, resolved at most once per render call. */
    private gpuCullingForRenderCall;
    /** Marks the compute graphs as structurally stale. */
    private invalidateCulling;
    /**
     * Returns `'gpu'` when the GPU path may run, or `null` when the mesh's
     * configuration requires the CPU fallback.
     */
    private resolveGPUCulling;
    /** A human-readable reason the GPU path cannot run, or `null`. */
    private gpuCullingBlocker;
    private maxStorageBuffersPerShaderStage;
    private levelsForPass;
    /**
     * Runs whatever this pass needs before its draws: either one GPU dispatch
     * for the whole mesh, or the shared CPU culling plus its uploads.
     */
    private updatePass;
    private flushPayloads;
    /**
     * Prepared from a render callback on purpose: Three submits a compute group
     * on its own encoder immediately, ahead of the enclosing render pass.
     * See docs/webgpu-architecture.md.
     */
    private prepareCulling;
    private cullingSphere;
    private buildDescriptor;
    /**
     * Points this object's draw at the right indirect command, or falls back to
     * the CPU-known instance count.
     */
    private prepareDraw;
    private get webgpuOwner();
    private get indexStorage();
    private get shadowIndexStorage();
    private get matrixStorage();
    private get colorStorage();
    private installWebGPUMaterial;
    private rebuildLODMaterialNodes;
    private rebuildMaterialNodes;
    /**
     * A shadow-only LOD has no material parameter of its own. Clone the owner's
     * uncomposed source state so alpha masking, custom normals and local vertex
     * deformation survive without wrapping the owner's already-instanced graph
     * a second time.
     */
    private createShadowLODSourceMaterial;
}
//# sourceMappingURL=InstancedMesh2.webgpu.d.ts.map