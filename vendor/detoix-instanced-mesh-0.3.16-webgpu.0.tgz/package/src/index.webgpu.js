export * from './index.common.js';
export { InstancedMesh2WebGPU as InstancedMesh2 } from './core/InstancedMesh2.webgpu.js';
export { setWebGPUInstancePositionNode } from './shaders/tsl/IndexedInstancing.js';
//# sourceMappingURL=index.webgpu.js.map