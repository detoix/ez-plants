import { Fn, instanceIndex, materialColor, normalLocal, positionLocal, storage, transformNormal, vec4 } from 'three/tsl';
const _instancePositionNodeFactories = new WeakMap();
/**
 * Attach an instance-aware local-position stage to a WebGPU source material.
 *
 * The backend captures this factory before cloning the material, so it remains
 * attached to every mesh-local graph rebuilt for LODs and buffer growth. Pass
 * `null` to remove a previously attached factory before constructing a mesh.
 */
export function setWebGPUInstancePositionNode(material, factory) {
    if (!material?.isMaterial) {
        throw new TypeError('setWebGPUInstancePositionNode requires a Three.js material.');
    }
    if (factory !== null && typeof factory !== 'function') {
        throw new TypeError('The WebGPU instance position node factory must be a function or null.');
    }
    if (factory === null)
        _instancePositionNodeFactories.delete(material);
    else
        _instancePositionNodeFactories.set(material, factory);
    return material;
}
/** @internal */
export function getWebGPUInstancePositionNodeFactory(material) {
    return _instancePositionNodeFactories.get(material) ?? null;
}
/**
 * Builds a material-local TSL graph for visible-index indirection.
 *
 * `instanceIndex` addresses the compact visible list. That list resolves the
 * stable instance id used to fetch the matrix and optional color. Keeping the
 * lookup in the shader lets CPU culling and LOD reorder instances without
 * copying their matrix/color payloads.
 */
export function createIndexedInstancingNodes(geometry, indexAttribute, matrixAttribute, colorAttribute, capacity, basePositionNode, baseColorNode, instancePositionNodeFactory) {
    const indexStorage = storage(indexAttribute, 'uint', capacity).toReadOnly();
    const matrixStorage = storage(matrixAttribute, 'mat4', capacity).toReadOnly();
    const stableInstanceId = indexStorage.element(instanceIndex);
    const instanceMatrix = matrixStorage.element(stableInstanceId);
    const localPositionNode = basePositionNode ?? positionLocal;
    // Capture the geometry-local normal before the Fn below assigns the
    // instance-transformed value back to Three's normalLocal property. A
    // deformation factory using this context must not observe that later write.
    const localNormalNode = normalLocal.toVar();
    const deformedPositionNode = instancePositionNodeFactory?.({
        positionNode: localPositionNode,
        normalNode: localNormalNode,
        instanceMatrix,
        instanceId: stableInstanceId,
        drawInstanceIndex: instanceIndex,
        geometry
    }) ?? localPositionNode;
    const positionNode = Fn(() => {
        if (geometry.hasAttribute('normal')) {
            normalLocal.assign(transformNormal(localNormalNode, instanceMatrix));
        }
        return instanceMatrix.mul(vec4(deformedPositionNode, 1)).xyz;
    })();
    let colorNode = null;
    if (colorAttribute !== null) {
        const colorStorage = storage(colorAttribute, 'vec4', capacity).toReadOnly();
        const instanceColor = colorStorage.element(stableInstanceId);
        colorNode = vec4(baseColorNode ?? materialColor).mul(instanceColor);
    }
    return { positionNode, colorNode };
}
//# sourceMappingURL=IndexedInstancing.js.map