import { type BufferGeometry, type Material, type StorageBufferAttribute } from 'three/webgpu';
/**
 * Nodes and immutable CPU context available to a WebGPU instance-position
 * factory. `instanceId` is the stable id resolved through the compact visible
 * index, while `drawInstanceIndex` is that compact draw slot itself.
 */
export interface WebGPUInstancePositionNodeContext {
    readonly positionNode: any;
    readonly normalNode: any;
    readonly instanceMatrix: any;
    readonly instanceId: any;
    readonly drawInstanceIndex: any;
    readonly geometry: BufferGeometry;
}
/** Return a local-space TSL `vec3`; indexed instancing is applied afterwards. */
export type WebGPUInstancePositionNodeFactory = (context: WebGPUInstancePositionNodeContext) => any;
/**
 * Attach an instance-aware local-position stage to a WebGPU source material.
 *
 * The backend captures this factory before cloning the material, so it remains
 * attached to every mesh-local graph rebuilt for LODs and buffer growth. Pass
 * `null` to remove a previously attached factory before constructing a mesh.
 */
export declare function setWebGPUInstancePositionNode<TMaterial extends Material>(material: TMaterial, factory: WebGPUInstancePositionNodeFactory | null): TMaterial;
export interface IndexedInstancingNodes {
    positionNode: any;
    colorNode: any | null;
}
/**
 * Builds a material-local TSL graph for visible-index indirection.
 *
 * `instanceIndex` addresses the compact visible list. That list resolves the
 * stable instance id used to fetch the matrix and optional color. Keeping the
 * lookup in the shader lets CPU culling and LOD reorder instances without
 * copying their matrix/color payloads.
 */
export declare function createIndexedInstancingNodes(geometry: BufferGeometry, indexAttribute: StorageBufferAttribute, matrixAttribute: StorageBufferAttribute, colorAttribute: StorageBufferAttribute | null, capacity: number, basePositionNode: any | null, baseColorNode: any | null, instancePositionNodeFactory: WebGPUInstancePositionNodeFactory | null): IndexedInstancingNodes;
/**
 * Node fields exist on NodeMaterial and are copied by WebGPURenderer's
 * material adapter for compatible classic materials.
 */
export interface NodeCompatibleMaterial extends Material {
    castShadowPositionNode?: any | null;
    colorNode?: any | null;
    normalNode?: any | null;
    positionNode?: any | null;
}
//# sourceMappingURL=IndexedInstancing.d.ts.map