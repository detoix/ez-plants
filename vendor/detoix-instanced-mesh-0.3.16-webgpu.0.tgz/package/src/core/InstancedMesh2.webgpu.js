import { BufferAttribute, Material, MeshBasicNodeMaterial } from 'three/webgpu';
import { InstancedMesh2 } from './InstancedMesh2.js';
import { WebGPUFloatStorageBuffer, WebGPUVisibleIndexBuffer } from './utils/WebGPUStorageBuffer.js';
import { createIndexedInstancingNodes, getWebGPUInstancePositionNodeFactory, setWebGPUInstancePositionNode } from '../shaders/tsl/IndexedInstancing.js';
const _materialBaseNodes = new WeakMap();
const _webgpuMaterialStates = new WeakMap();
/**
 * WebGPU renderer backend for InstancedMesh2.
 *
 * Instance allocation, stable ids, visibility, CPU frustum culling, BVH and
 * LOD remain inherited from the shared core. This class replaces only the
 * WebGL texture/attribute shader path with persistent storage buffers and TSL
 * visible-index indirection.
 */
export class InstancedMesh2WebGPU extends InstancedMesh2 {
    // @ts-expect-error Three declares material as a property; the accessor is
    // needed to rebuild mesh-local storage bindings on replacement.
    get material() {
        return (_webgpuMaterialStates.get(this)?.value ?? null);
    }
    set material(value) {
        const state = _webgpuMaterialStates.get(this);
        if (!state) {
            _webgpuMaterialStates.set(this, { ready: false, value });
            return;
        }
        if (!state.ready) {
            state.value = value;
            return;
        }
        this.installWebGPUMaterial(value);
    }
    constructor(geometry, material, params = {}, LOD) {
        const { renderer: _renderer, ...commonParams } = params;
        super(geometry, material, commonParams, LOD);
        // Keep Three's native marker so every mesh gets an object-specific node
        // binding cache, including the count === 1 case. A plain BufferAttribute
        // deliberately fails NodeMaterial's InstancedBufferAttribute guard, so
        // only our storage-buffer transform is applied. It also keeps toJSON()
        // safe without allocating a duplicate matrix payload.
        this.isInstancedMesh = true;
        this.instanceMatrix = new BufferAttribute(new Float32Array(0), 16);
        this.instanceColor = null;
        this._shadowPassDepth = 0;
        this._webgpuBindingRevision = 0;
        this._webgpuDisposed = false;
        _webgpuMaterialStates.get(this).ready = true;
        this.installWebGPUMaterial(material);
    }
    initIndexAttribute() {
        this.instanceIndex = new WebGPUVisibleIndexBuffer(this._capacity);
        this._shadowInstanceIndex = new WebGPUVisibleIndexBuffer(this._capacity, 'ezShadowInstanceIndex');
        this.count = 0;
    }
    /** @internal */
    getInstanceIndexForPass(isShadowPass = false) {
        return (isShadowPass ? this._shadowInstanceIndex : this.instanceIndex);
    }
    initMatricesTexture() {
        if (!this._parentLOD) {
            this.matricesTexture = new WebGPUFloatStorageBuffer(16, this._capacity, 'ezInstanceMatrices');
        }
    }
    initColorsTexture() {
        if (this._parentLOD)
            return;
        const colors = new WebGPUFloatStorageBuffer(4, this._capacity, 'ezInstanceColors');
        colors._data.fill(1);
        colors.enqueueFullUpdate();
        this.colorsTexture = colors;
        this.rebuildLODMaterialNodes();
    }
    /** WebGPU does not add a synthetic vertex attribute to user geometry. */
    patchGeometry(_geometry) {
        // Mesh's constructor reaches this override before the subclass fields are
        // initialized. Later geometry replacements must refresh the conditional
        // normal transform captured by the TSL graph.
        if (this._ownedWebGPUMaterials)
            this.rebuildMaterialNodes();
    }
    materialsNeedsUpdate() {
        if (!this._ownedWebGPUMaterials)
            return;
        this.rebuildLODMaterialNodes();
    }
    onBeforeShadow(renderer, _scene, _camera, shadowCamera, _geometry, _depthMaterial, _group) {
        this._shadowPassDepth++;
        const owner = this.webgpuOwner;
        if (owner.instanceIndex && owner.autoUpdate) {
            const renderCall = getRenderCall(renderer);
            if (!owner.frustumCullingAlreadyPerformed(renderCall, shadowCamera, shadowCamera)) {
                // WebGPURenderer renders the shadow scene with `shadow.camera`, so
                // Three r185 supplies that same camera in both callback camera slots.
                // Pass identity must therefore be explicit rather than inferred from
                // camera reference inequality.
                owner.performFrustumCulling(shadowCamera, shadowCamera, true);
            }
        }
    }
    onBeforeRender(renderer, _scene, camera, _geometry, _material, _group) {
        const owner = this.webgpuOwner;
        if (owner.instanceIndex && owner.autoUpdate && this._shadowPassDepth === 0) {
            const renderCall = getRenderCall(renderer);
            if (!owner.frustumCullingAlreadyPerformed(renderCall, camera, null)) {
                owner.performFrustumCulling(camera);
            }
        }
        owner.matrixStorage.flush(owner._instancesArrayCount);
        owner.colorStorage?.flush(owner._instancesArrayCount);
        const indexStorage = this._shadowPassDepth > 0
            ? this.shadowIndexStorage
            : this.indexStorage;
        indexStorage.update(renderer, this.count);
    }
    onAfterShadow(_renderer, _scene, _camera, _shadowCamera, _geometry, _depthMaterial, _group) {
        this._shadowPassDepth = Math.max(0, this._shadowPassDepth - 1);
    }
    onAfterRender(_renderer, _scene, _camera, _geometry, _material, _group) { }
    resizeBuffers(capacity) {
        super.resizeBuffers(capacity);
        const owner = this.webgpuOwner;
        owner.shadowIndexStorage.resize(capacity);
        for (const object of owner.LODinfo?.objects ?? []) {
            if (object !== owner && object instanceof InstancedMesh2WebGPU) {
                object.shadowIndexStorage.resize(capacity);
            }
        }
        owner.rebuildLODMaterialNodes();
        return this;
    }
    /** @internal */
    addLevel(renderList, geometry, material, distance, hysteresis) {
        const objectsList = this.LODinfo.objects;
        const levels = renderList.levels;
        const squaredDistance = distance ** 2;
        let object;
        const objectIndex = objectsList.findIndex((entry) => entry.geometry === geometry);
        if (objectIndex === -1) {
            const temporaryShadowMaterial = material ? null : this.createShadowLODSourceMaterial();
            const levelMaterial = material ?? temporaryShadowMaterial ?? new MeshBasicNodeMaterial();
            try {
                object = new InstancedMesh2WebGPU(geometry, levelMaterial, { capacity: this._capacity }, this);
            }
            finally {
                if (temporaryShadowMaterial) {
                    const temporaryMaterials = Array.isArray(temporaryShadowMaterial)
                        ? temporaryShadowMaterial
                        : [temporaryShadowMaterial];
                    for (const temporaryMaterial of temporaryMaterials)
                        temporaryMaterial.dispose();
                }
            }
            object.frustumCulled = false;
            this.patchLevel(object);
            objectsList.push(object);
            this.add(object);
        }
        else {
            object = objectsList[objectIndex];
            if (material)
                object.installWebGPUMaterial(material);
        }
        let index = 0;
        for (; index < levels.length; index++) {
            if (squaredDistance < levels[index].distance)
                break;
        }
        levels.splice(index, 0, { distance: squaredDistance, hysteresis, object });
        renderList.count.push(0);
        return object;
    }
    /** @internal */
    disposeLOD(object) {
        object.geometry.dispose();
        if (object instanceof InstancedMesh2WebGPU) {
            object.dispose();
            return;
        }
        const materials = Array.isArray(object.material) ? object.material : [object.material];
        for (const material of materials)
            material.dispose();
    }
    initUniformsPerInstance(_schema) {
        throw unsupportedFeature('per-instance uniforms');
    }
    initSkeleton(_skeleton, _disableMatrixAutoUpdate = true) {
        throw unsupportedFeature('instanced skinning');
    }
    setMorphAt(_id, _object) {
        throw unsupportedFeature('per-instance morph targets');
    }
    clone(_recursive) {
        throw unsupportedFeature('clone/copy');
    }
    copy(_source, _recursive) {
        throw unsupportedFeature('clone/copy');
    }
    dispose() {
        if (this._webgpuDisposed)
            return;
        this._webgpuDisposed = true;
        this.dispatchEvent({ type: 'dispose' });
        this.indexStorage.dispose();
        this.shadowIndexStorage.dispose();
        if (!this._parentLOD) {
            this.matrixStorage.dispose();
            this.colorStorage?.dispose();
            for (const object of this.LODinfo?.objects ?? []) {
                if (object !== this && object instanceof InstancedMesh2WebGPU)
                    object.dispose();
            }
        }
        for (const material of this._ownedWebGPUMaterials)
            material.dispose();
        this._ownedWebGPUMaterials.length = 0;
    }
    get webgpuOwner() {
        return this._parentLOD ?? this;
    }
    get indexStorage() {
        return this.instanceIndex;
    }
    get shadowIndexStorage() {
        return this._shadowInstanceIndex;
    }
    get matrixStorage() {
        return this.matricesTexture;
    }
    get colorStorage() {
        return this.colorsTexture;
    }
    installWebGPUMaterial(material) {
        const sources = Array.isArray(material) ? material : [material];
        for (const source of sources)
            assertWebGPUCompatibleMaterial(source);
        const materials = sources.map((source) => {
            const clone = source.clone();
            const sourceProgramCacheKey = clone.customProgramCacheKey.bind(clone);
            clone.customProgramCacheKey = () => `${sourceProgramCacheKey()}|ez-webgpu-bindings:${this._webgpuBindingRevision}`;
            const sourceNodes = source;
            // If another WebGPU InstancedMesh2-owned material is deliberately reused
            // as a source, unwrap its source graph. Treating the composed
            // positionNode as a new base would apply indexed instancing twice.
            const inheritedBaseNodes = _materialBaseNodes.get(source);
            const castShadowPositionNode = inheritedBaseNodes
                ? inheritedBaseNodes.castShadowPositionNode
                : (sourceNodes.castShadowPositionNode ?? null);
            const colorNode = inheritedBaseNodes
                ? inheritedBaseNodes.colorNode
                : (sourceNodes.colorNode ?? null);
            const normalNode = inheritedBaseNodes
                ? inheritedBaseNodes.normalNode
                : (sourceNodes.normalNode ?? null);
            const positionNode = inheritedBaseNodes
                ? inheritedBaseNodes.positionNode
                : (sourceNodes.positionNode ?? null);
            const instancePositionNodeFactory = getWebGPUInstancePositionNodeFactory(source)
                ?? inheritedBaseNodes?.instancePositionNodeFactory
                ?? null;
            // Classic materials do not promise to copy NodeMaterial extension
            // fields. Preserve all source nodes explicitly before composing the
            // mesh-local indexed-instancing graph.
            clone.castShadowPositionNode = castShadowPositionNode;
            clone.colorNode = colorNode;
            clone.normalNode = normalNode;
            clone.positionNode = positionNode;
            _materialBaseNodes.set(clone, {
                castShadowPositionNode,
                colorNode,
                normalNode,
                positionNode,
                instancePositionNodeFactory
            });
            return clone;
        });
        const previousMaterials = this._ownedWebGPUMaterials;
        const previousValue = _webgpuMaterialStates.get(this).value;
        this._ownedWebGPUMaterials = materials;
        _webgpuMaterialStates.get(this).value = Array.isArray(material) ? materials : materials[0];
        try {
            this.rebuildMaterialNodes();
        }
        catch (error) {
            this._ownedWebGPUMaterials = previousMaterials;
            _webgpuMaterialStates.get(this).value = previousValue;
            for (const ownedMaterial of materials)
                ownedMaterial.dispose();
            throw error;
        }
        for (const ownedMaterial of previousMaterials ?? [])
            ownedMaterial.dispose();
    }
    rebuildLODMaterialNodes() {
        const owner = this.webgpuOwner;
        owner.rebuildMaterialNodes();
        for (const object of owner.LODinfo?.objects ?? []) {
            if (object !== owner && object instanceof InstancedMesh2WebGPU) {
                object.rebuildMaterialNodes();
            }
        }
    }
    rebuildMaterialNodes() {
        if (!this._ownedWebGPUMaterials)
            return;
        // StorageBufferAttribute cannot be resized in place. The storage wrappers
        // therefore replace their attributes on growth, and Three must discard
        // the RenderObject that still owns bindings for the previous attributes.
        // Including this revision in customProgramCacheKey makes needsUpdate take
        // the cache-miss path instead of retaining those stale bindings.
        this._webgpuBindingRevision++;
        const owner = this.webgpuOwner;
        const colorAttribute = owner.colorStorage?.attribute ?? null;
        for (const material of this._ownedWebGPUMaterials) {
            const baseNodes = _materialBaseNodes.get(material);
            const nodes = createIndexedInstancingNodes(this.geometry, this.indexStorage.attribute, owner.matrixStorage.attribute, colorAttribute, owner._capacity, baseNodes?.positionNode ?? null, baseNodes?.colorNode ?? null, baseNodes?.instancePositionNodeFactory ?? null);
            const shadowNodes = createIndexedInstancingNodes(this.geometry, this.shadowIndexStorage.attribute, owner.matrixStorage.attribute, null, owner._capacity, baseNodes?.castShadowPositionNode ?? baseNodes?.positionNode ?? null, null, baseNodes?.instancePositionNodeFactory ?? null);
            material.positionNode = nodes.positionNode;
            material.castShadowPositionNode = shadowNodes.positionNode;
            material.colorNode = nodes.colorNode ?? baseNodes?.colorNode ?? null;
            material.normalNode = baseNodes?.normalNode ?? null;
            material.needsUpdate = true;
        }
    }
    /**
     * A shadow-only LOD has no material parameter of its own. Clone the owner's
     * uncomposed source state so alpha masking, custom normals and local vertex
     * deformation survive without wrapping the owner's already-instanced graph
     * a second time.
     */
    createShadowLODSourceMaterial() {
        if (!this._ownedWebGPUMaterials?.length)
            return null;
        const sources = this._ownedWebGPUMaterials.map((ownedMaterial) => {
            const baseNodes = _materialBaseNodes.get(ownedMaterial);
            const source = ownedMaterial.clone();
            source.castShadowPositionNode = baseNodes?.castShadowPositionNode ?? null;
            source.colorNode = baseNodes?.colorNode ?? null;
            source.normalNode = baseNodes?.normalNode ?? null;
            source.positionNode = baseNodes?.positionNode ?? null;
            if (baseNodes?.instancePositionNodeFactory) {
                setWebGPUInstancePositionNode(source, baseNodes.instancePositionNodeFactory);
            }
            return source;
        });
        return Array.isArray(this.material) ? sources : sources[0];
    }
}
function getRenderCall(renderer) {
    return renderer.info.calls;
}
function assertWebGPUCompatibleMaterial(material) {
    if (isShaderMaterial(material)
        && !material.isNodeMaterial) {
        throw new Error('InstancedMesh2 WebGPU does not support ShaderMaterial. Use a NodeMaterial/TSL material.');
    }
    const isNodeMaterial = !!material.isNodeMaterial;
    if (!isNodeMaterial && material.onBeforeCompile !== Material.prototype.onBeforeCompile) {
        throw new Error('InstancedMesh2 WebGPU cannot run a GLSL onBeforeCompile customization. '
            + 'Port the material customization to NodeMaterial/TSL.');
    }
}
function isShaderMaterial(material) {
    return !!material.isShaderMaterial;
}
function unsupportedFeature(feature) {
    return new Error(`InstancedMesh2 WebGPU does not support ${feature} yet.`);
}
//# sourceMappingURL=InstancedMesh2.webgpu.js.map