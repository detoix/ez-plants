import { type BufferGeometry, type Camera, Material, type Mesh, type Object3DEventMap, type Scene, type Skeleton, type WebGPURenderer } from 'three/webgpu';
import { InstancedMesh2, type InstancedMesh2Params } from './InstancedMesh2.js';
export interface InstancedMesh2WebGPUParams extends Omit<InstancedMesh2Params, 'renderer'> {
    /**
     * Accepted for constructor parity. WebGPU buffers do not need a renderer in
     * order to be allocated, so initialization remains eager without it.
     */
    renderer?: WebGPURenderer;
}
/**
 * WebGPU renderer backend for InstancedMesh2.
 *
 * Instance allocation, stable ids, visibility, CPU frustum culling, BVH and
 * LOD remain inherited from the shared core. This class replaces only the
 * WebGL texture/attribute shader path with persistent storage buffers and TSL
 * visible-index indirection.
 */
export declare class InstancedMesh2WebGPU<TData = {}, TGeometry extends BufferGeometry = BufferGeometry, TMaterial extends Material | Material[] = Material | Material[], TEventMap extends Object3DEventMap = Object3DEventMap> extends InstancedMesh2<TData, TGeometry, TMaterial, TEventMap> {
    private _ownedWebGPUMaterials;
    private _shadowInstanceIndex;
    private _shadowPassDepth;
    private _webgpuBindingRevision;
    private _webgpuDisposed;
    get material(): TMaterial;
    set material(value: TMaterial);
    constructor(geometry: TGeometry, material: TMaterial, params?: InstancedMesh2WebGPUParams, LOD?: InstancedMesh2WebGPU);
    constructor(geometry: TGeometry, material: TMaterial, params?: InstancedMesh2WebGPUParams);
    protected initIndexAttribute(): void;
    protected initMatricesTexture(): void;
    protected initColorsTexture(): void;
    /** WebGPU does not add a synthetic vertex attribute to user geometry. */
    protected patchGeometry(_geometry: TGeometry): void;
    protected materialsNeedsUpdate(): void;
    onBeforeShadow(renderer: any, _scene: Scene, _camera: Camera, shadowCamera: Camera, _geometry: BufferGeometry, _depthMaterial: Material, _group: any): void;
    onBeforeRender(renderer: any, _scene: Scene, camera: Camera, _geometry: BufferGeometry, _material: Material, _group: any): void;
    onAfterShadow(_renderer: any, _scene: Scene, _camera: Camera, _shadowCamera: Camera, _geometry: BufferGeometry, _depthMaterial: Material, _group: any): void;
    onAfterRender(_renderer: any, _scene: Scene, _camera: Camera, _geometry: BufferGeometry, _material: Material, _group: any): void;
    resizeBuffers(capacity: number): this;
    initUniformsPerInstance(_schema: unknown): void;
    initSkeleton(_skeleton: Skeleton, _disableMatrixAutoUpdate?: boolean): void;
    setMorphAt(_id: number, _object: Mesh): void;
    clone(_recursive?: boolean): this;
    copy(_source: InstancedMesh2, _recursive?: boolean): this;
    dispose(): void;
    private get webgpuOwner();
    private get indexStorage();
    private get shadowIndexStorage();
    private get matrixStorage();
    private get colorStorage();
    private installWebGPUMaterial;
    private rebuildLODMaterialNodes;
    private rebuildMaterialNodes;
    /**
     * A shadow-only LOD has no material parameter of its own. Clone the owner's
     * uncomposed source state so alpha masking, custom normals and local vertex
     * deformation survive without wrapping the owner's already-instanced graph
     * a second time.
     */
    private createShadowLODSourceMaterial;
}
//# sourceMappingURL=InstancedMesh2.webgpu.d.ts.map