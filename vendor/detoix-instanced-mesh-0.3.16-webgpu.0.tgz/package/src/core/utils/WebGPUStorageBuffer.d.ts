import { StorageBufferAttribute, type WebGPURenderer } from 'three/webgpu';
/**
 * Minimal image-shaped view used by {@link WebGPUFloatStorageBuffer}.
 *
 * `InstancedMesh2` historically stores instance data in a `DataTexture`, so
 * some of its common code accesses `image.data`. The accessor below keeps
 * that API without allocating a texture or duplicating the backing array.
 */
export interface WebGPUStorageBufferImage {
    data: Float32Array;
    readonly width: number;
    readonly height: number;
}
/**
 * CPU-backed float storage buffer with one contiguous dirty range.
 *
 * The buffer is suitable for matrices (`itemSize = 16`) and colors
 * (`itemSize = 4`). Calls to `enqueueUpdate()` only widen the pending range;
 * they never create one update range per instance.
 */
export declare class WebGPUFloatStorageBuffer {
    _data: Float32Array;
    attribute: StorageBufferAttribute;
    readonly image: WebGPUStorageBufferImage;
    readonly itemSize: number;
    /** Increments whenever `attribute` is replaced. */
    revision: number;
    private _dirtyStart;
    private _dirtyEnd;
    constructor(itemSize: number, capacity: number, name?: string);
    /** Number of logical items currently allocated. */
    get capacity(): number;
    /**
     * Marks a logical item as changed. Multiple calls are coalesced into one
     * component range by `flush()`.
     */
    enqueueUpdate(index: number): void;
    /** Marks every allocated item as changed. */
    enqueueFullUpdate(): void;
    /**
     * Publishes the pending CPU changes to Three.js.
     *
     * `count` optionally limits the upload to the first N logical items. Any
     * pending tail remains queued for a later flush. Existing, not-yet-consumed
     * Three.js update ranges are merged so there is always at most one range.
     *
     * @returns `true` when an upload was scheduled.
     */
    flush(count?: number): boolean;
    /**
     * Reallocates the storage attribute while preserving the overlapping data.
     * Consumers holding a TSL storage node must rebuild it when `revision`
     * changes because the `attribute` identity changes.
     */
    resize(capacity: number): void;
    clone(): WebGPUFloatStorageBuffer;
    dispose(): void;
    private createImageView;
    private replaceData;
    private clearPendingRange;
}
/**
 * CPU-written visible-instance indirection buffer for WebGPU.
 *
 * Its `array`, `_needsUpdate`, and `update(renderer, count)` surface mirrors
 * the existing WebGL index attribute closely enough for the shared culling
 * and LOD code. Each update uploads one `[0, count)` range.
 */
export declare class WebGPUVisibleIndexBuffer {
    attribute: StorageBufferAttribute;
    _needsUpdate: boolean;
    /** Increments whenever `attribute` is replaced. */
    revision: number;
    private _array;
    constructor(capacity: number, name?: string);
    get array(): Uint32Array;
    set array(value: Uint32Array);
    get capacity(): number;
    /**
     * Reallocates the storage attribute, preserves existing indices, and fills
     * newly allocated entries with their identity index.
     */
    resize(capacity: number): void;
    /**
     * Schedules one contiguous upload for the visible prefix. The renderer
     * parameter is intentionally unused; it is retained for WebGL API parity.
     */
    update(_renderer: WebGPURenderer | null | undefined, count: number): boolean;
    /** Renderer-independent alias for `update()`. */
    flush(count: number): boolean;
    clone(): WebGPUVisibleIndexBuffer;
    dispose(): void;
    private replaceArray;
}
//# sourceMappingURL=WebGPUStorageBuffer.d.ts.map