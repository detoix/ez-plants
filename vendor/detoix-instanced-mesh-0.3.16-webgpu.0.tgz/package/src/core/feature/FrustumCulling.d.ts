import { Camera } from 'three';
import { InstancedRenderItem } from '../utils/InstancedRenderList.js';
/**
 * A custom sorting callback for render items.
 */
export type CustomSortCallback = (list: InstancedRenderItem[]) => void;
/**
 * Callback invoked when an instance is within the frustum.
 * @param index The index of the instance.
 * @param camera The camera used for rendering.
 * @param cameraLOD The camera used for LOD calculations (provided only if LODs are initialized).
 * @param LODindex The LOD level of the instance (provided only if LODs are initialized and `sortObjects` is false).
 * @returns True if the instance should be rendered, false otherwise.
 */
export type OnFrustumEnterCallback = (index: number, camera: Camera, cameraLOD?: Camera, LODindex?: number) => boolean;
/**
 * Resolves the final LOD level for one visible instance.
 * Invalid return values fall back to the distance-selected level.
 */
export type ResolveLODIndexCallback = (index: number, camera: Camera, cameraLOD: Camera, computedIndex: number, isShadowPass: boolean) => number;
declare module '../InstancedMesh2.js' {
    interface InstancedMesh2 {
        /**
         * Performs frustum culling and manages LOD visibility.
         * @param camera The camera used for frustum culling. This is the shadow camera during an explicit shadow pass.
         * @param cameraLOD An optional camera for LOD calculations. Defaults to the culling camera.
         * @param isShadowPass Explicitly selects the shadow LOD list. Defaults to whether the two cameras differ.
         */
        performFrustumCulling(camera: Camera, cameraLOD?: Camera, isShadowPass?: boolean): void;
    }
}
//# sourceMappingURL=FrustumCulling.d.ts.map